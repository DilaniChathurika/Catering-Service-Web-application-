window.API_URL =  "http://localhost:3001/api/"
// window.API_URL =  'https://a3b1-112-134-152-171.ngrok-free.app/api/'


window.IMAGE_URL =  "http://localhost:3001/uploads/"
// window.IMAGE_URL =  "https://a3b1-112-134-152-171.ngrok-free.app/uploads/"
